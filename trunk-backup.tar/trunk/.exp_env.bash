#!/bin/bash

export SCP_PATH="/usr/bin/scp"
export SSH_PATH="/usr/bin/ssh"
export MV_PATH="/bin/mv"
export PYTHON_PATH="/usr/local/bin/python"
export CHMOD_PATH="/bin/chmod"
export ENV_PATH="/usr/bin/env"
export SED_PATH="/usr/bin/sed"
export MKDIR="/bin/mkdir"

