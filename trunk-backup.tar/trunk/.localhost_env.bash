#!/usr/local/bin/bash

export CP=/bin/cp
export TOUCH=/usr/bin/touch
export QSUB=/bin/csh
export QSTAT=/usr/pbs/bin/qstat
export HOSTNAME=/bin/hostname
export MKDIR=/bin/mkdir
export LS=/bin/ls
export CVS=/usr/bin/cvs
export QDEL=/usr/pbs/bin/qdel

