GmiProduction
=============

This repository contains the back-end workflow software for GMI production workflows. The workflow engine is assumed to be NASA Experiment Designer (NED). https://modelingguru.nasa.gov/docs/DOC-1938 
