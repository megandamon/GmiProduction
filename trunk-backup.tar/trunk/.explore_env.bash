#!/usr/local/bin/bash

export CP=/bin/cp
export TOUCH=/usr/bin/touch
export QSUB=/pbs/bin/qsub
export QSTAT=/pbs/bin/qstat
export MKDIR=/bin/mkdir
