$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/modify_namelist.bash >> $NED_WORKING_DIR/$NED_UNIQUE_ID/log/modify_namelist.log

