$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/run_gmi_segment.bash >> $NED_WORKING_DIR/$NED_UNIQUE_ID/log/run_gmi_segment.log

