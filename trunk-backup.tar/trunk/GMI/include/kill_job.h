$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/kill_job.bash  > $NED_WORKING_DIR/$NED_UNIQUE_ID/log/kill_job.log
/bin/chmod 755 $NED_WORKING_DIR/$NED_UNIQUE_ID/log/kill_job.log
