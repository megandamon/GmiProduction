$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/check_ssh_keys.bash > $NED_WORKING_DIR/$NED_UNIQUE_ID/log/check_ssh_keys.log

