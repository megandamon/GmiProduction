$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/setup_wf_env.bash > $NED_WORKING_DIR/$NED_UNIQUE_ID/log/setup_wf_env.log

