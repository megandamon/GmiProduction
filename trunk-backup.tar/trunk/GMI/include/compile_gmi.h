$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/compile_gmi.bash > $NED_WORKING_DIR/$NED_UNIQUE_ID/log/compile_gmi.log

