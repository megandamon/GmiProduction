$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/create_pbs_script.bash >> $NED_WORKING_DIR/$NED_UNIQUE_ID/log/create_pbs_script.log

