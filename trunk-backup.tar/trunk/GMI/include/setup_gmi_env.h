$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/setup_gmi_env.bash > $NED_WORKING_DIR/$NED_UNIQUE_ID/log/setup_gmi_env.log

