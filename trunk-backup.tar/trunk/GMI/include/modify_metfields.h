$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/modify_metfields.bash >> $NED_WORKING_DIR/$NED_UNIQUE_ID/log/modify_metfields.log

