$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/transfer_output.bash >> $NED_WORKING_DIR/$NED_UNIQUE_ID/log/transfer_output.log

