$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/clean_env.bash >> $NED_WORKING_DIR/$NED_UNIQUE_ID/log/clean_env.log

