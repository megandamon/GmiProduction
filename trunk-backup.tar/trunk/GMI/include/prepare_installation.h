$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/prepare_installation.bash > $NED_WORKING_DIR/$NED_UNIQUE_ID/log/prepare_installation.log

