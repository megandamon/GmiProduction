$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/setup_input_files.bash > $NED_WORKING_DIR/$NED_UNIQUE_ID/log/setup_input_files.log

