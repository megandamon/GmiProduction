smscomplete  # Notify SMS of a normal end
trap 0       # Remove all traps
exit 0       # End the shell
