$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/archive_outputs.bash >> $NED_WORKING_DIR/$NED_UNIQUE_ID/log/archive_outputs.log

