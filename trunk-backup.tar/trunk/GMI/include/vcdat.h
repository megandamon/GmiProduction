$NED_WORKING_DIR/$NED_UNIQUE_ID/bin/vcdat.bash >> $NED_WORKING_DIR/$NED_UNIQUE_ID/log/vcdat.log

